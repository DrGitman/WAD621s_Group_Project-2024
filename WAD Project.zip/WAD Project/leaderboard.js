// Sample data for leaderboard
var leaderboardData = [
    { name: "Ornell", points: 1500 },
    { name: "Alex", points: 1200 },
    { name: "Sam", points: 1000 },
    { name: "Jamie", points: 900 },
];

// Function to render leaderboard
function renderLeaderboard() {
    var leaderboardBody = document.getElementById("leaderboard").getElementsByTagName("tbody")[0];
    leaderboardBody.innerHTML = ""; // Clear existing data

    leaderboardData.sort((a, b) => b.points - a.points); // Sort by points descending

    leaderboardData.forEach((player, index) => {
        var row = leaderboardBody.insertRow();
        var rankCell = row.insertCell(0);
        var nameCell = row.insertCell(1);
        var pointsCell = row.insertCell(2);

        // Rank with icon for top 3
        if (index === 0) {
            rankCell.innerHTML = `<span class="rank-icon">🥇</span>`;
        } else if (index === 1) {
            rankCell.innerHTML = `<span class="rank-icon">🥈</span>`;
        } else if (index === 2) {
            rankCell.innerHTML = `<span class="rank-icon">🥉</span>`;
        } else {
            rankCell.innerText = index + 1; // Number for lower ranks
        }

        nameCell.innerText = player.name;
        pointsCell.innerText = player.points;
    });
}

// Initial render
renderLeaderboard();
