// Basic JavaScript to confirm the file is connected
console.log("About Us page loaded successfully.");
